﻿Public Class log_in

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If TextBox1.Text = "admin" And TextBox2.Text = "admin" Then
            main.Show()
            Me.Hide()
        Else
            MsgBox("Username or password not found!", MsgBoxStyle.OkOnly, "Log In Error")

        End If

    End Sub
End Class
