﻿Public Class release

    Private Sub InventoryBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Validate()
        Me.InventoryBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.WarehouseDataSet)

    End Sub

    Private Sub Form5_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        'TODO: This line of code loads data into the 'WarehouseDataSet.inventory' table. You can move, or remove it, as needed.
        Me.InventoryTableAdapter.Fill(Me.WarehouseDataSet.inventory)

        ListView1.View = View.Details
        ListView1.GridLines = True
        ListView1.FullRowSelect = True

        ListView1.Columns.Add("Item Code", 100)
        ListView1.Columns.Add("Item Description", 130)
        ListView1.Columns.Add("Items Added/Released", 70)
        ListView1.Columns.Add("Updated Quantity", 120)
        ListView1.Columns.Add("Unit Price", 80)
        ListView1.Columns.Add("Date Added", 100)
        ListView1.Columns.Add("Time Added", 100)

        category.Items.Add("Description")
        Timer1.Start()
        daaate.Text = Date.Today
    End Sub
    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        time.Text = TimeString
    End Sub


    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim tempQty As Integer
        Dim Qty As Integer

        tempQty = CInt(rlsQty.Text)
        Qty = CInt(QuantityTextBox.Text)

        If tempQty > Qty And Qty <> 0 Then
            MsgBox("PLEASE ENTER LESSER QUANTITY")
        End If
        If Qty = 0 Then
            MsgBox("OUT OF STOCK!!")
        End If
        If Qty > tempQty Or tempQty = Qty Then
            QuantityTextBox.Text = Qty - tempQty

        End If

        Me.Validate()
        Me.InventoryBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.WarehouseDataSet)

        'Add item to listview
        Dim arr(7) As String
        Dim itm As ListViewItem


        arr(0) = Item_NumberTextBox.Text
        arr(1) = DescriptionTextBox.Text
        arr(2) = rlsQty.Text
        arr(3) = QuantityTextBox.Text
        arr(4) = Unit_PriceTextBox.Text
        arr(5) = Date.Today
        arr(6) = time.Text

        itm = New ListViewItem(arr)
        ListView1.Items.Add(itm)
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        main.Show()
        Me.Hide()
    End Sub


    Private Sub printprvw_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles printprvw.Click
        Dim f2 As New prntpreview

        For Each itm As ListViewItem In ListView1.Items

            f2.ListView2.Items.Add(itm.Clone())

        Next
        f2.Show()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim item As String
        item = category.Text

        Select Case item
            Case "Description"
                Me.InventoryBindingSource.Filter = "Description = '" & textSearch.Text & "'"
        End Select
    End Sub

End Class